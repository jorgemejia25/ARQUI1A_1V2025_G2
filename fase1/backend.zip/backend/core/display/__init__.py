"""
Módulo de display del Sistema SIEPA
"""

from .display_manager import DisplayManager

__all__ = ['DisplayManager'] 