"""
Módulo de sensores del Sistema SIEPA
""" 