"""
Módulo core del Sistema SIEPA
Contiene la lógica principal de sensores, display y comunicación
""" 